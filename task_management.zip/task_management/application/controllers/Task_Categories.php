<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . "Libraries/Format.php";
require APPPATH . "Libraries/RestController.php";

use chriskacerguis\RestServer\RestController;

class Task_Categories extends RestController {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('TaskCategories_model', 'taskCategories');
    }

    public function index_get()
    {
        $id = $this->get('id');

        if($id === null){
            $taskCategories = $this->taskCategories->getTaskCategories();
        }else{
            $taskCategories = $this->taskCategories->getTaskCategories($id);
        }

        if($taskCategories){
            $this->response([
                'status' => true,
                'data' => $taskCategories,
            ], 200);
        }else{
            $this->response([
                'status' => false,
                'massage' => 'Id Not Found',
            ], 404);
        }
    }

    public function index_delete(){
        $id = $this->delete('id');
        if($id === null){
            $this->response([
                'status' => false,
                'massage' => 'Provide an ID!',
            ], 400);
        }else{
            if($this->taskCategories->deleteTaskCategories($id) > 0){
                $this->response([
                    'status' => true,
                    'data' => $id,
                    'massage' => 'Task Categories Deleted'
                ], 200);
            }else{
                $this->response([
                    'status' => false,
                    'massage' => 'Id Not Found',
                ], 404);
            }
        }
    }

    public function index_post(){
        $data = [
            'name' => $this->post('name')
        ];

        if($this->taskCategories->createTaskCategories($data)> 0){
            $this->response([
                'status' => true,
                'massage' => 'Task Categories Has Been Created'
            ], 201);
        }else{
            $this->response([
                'status' => false,
                'massage' => 'Create Task Categories Failed!',
            ], 400);
        }
    }

    public function index_put(){
        $id = $this->put('id');

        $data = [
            'name' => $this->put('name')
        ];

        if($this->taskCategories->updateTaskCategories($data, $id)> 0){
            $this->response([
                'status' => true,
                'massage' => 'Task Categories Has Been Updated'
            ], 200);
        }else{
            $this->response([
                'status' => false,
                'massage' => 'Update Task Categories Failed!',
            ], 400);
        }
    }
}