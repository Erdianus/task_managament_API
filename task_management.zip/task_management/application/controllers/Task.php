<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . "Libraries/Format.php";
require APPPATH . "Libraries/RestController.php";

use chriskacerguis\RestServer\RestController;

class Task extends RestController {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Task_model', 'task');
    }

    public function index_get()
    {
        $id = $this->get('id');

        if($id === null){
            $task = $this->task->getTask();
        }else{
            $task = $this->task->getTask($id);
        }

        if($task){
            $this->response([
                'status' => true,
                'data' => $task,
            ], 200);
        }else{
            $this->response([
                'status' => false,
                'massage' => 'Id Not Found',
            ], 404);
        }
    }

    public function index_delete(){
        $id = $this->delete('id');
        if($id === null){
            $this->response([
                'status' => false,
                'massage' => 'Provide an ID!',
            ], 400);
        }else{
            if($this->task->deleteTask($id) > 0){
                $this->response([
                    'status' => true,
                    'data' => $id,
                    'massage' => 'Task Deleted'
                ], 200);
            }else{
                $this->response([
                    'status' => false,
                    'massage' => 'Id Not Found',
                ], 404);
            }
        }
    }

    public function index_post(){
        $data = [
            'category_id' => $this->post('category_id'),
            'title' => $this->post('title'),
            'description' => $this->post('description'),
            'start_date' => $this->post('start_date'),
            'finish_date' => $this->post('finish_date'),
            'status' => $this->post('status'),
            'doc_url' => $this->post('doc_url')   
        ];

        if($this->task->createTask($data)> 0){
            $this->response([
                'status' => true,
                'massage' => 'Task Has Been Created'
            ], 201);
        }else{
            $this->response([
                'status' => false,
                'massage' => 'Create Task  Failed!',
            ], 400);
        }
    }

    public function index_put(){
        $id = $this->put('id');
        $data = [
            'category_id' => $this->put('category_id'),
            'title' => $this->put('title'),
            'description' => $this->put('description'),
            'start_date' => $this->put('start_date'),
            'finish_date' => $this->put('finish_date'),
            'status' => $this->put('status'),
            'doc_url' => $this->put('doc_url')   
        ];

        if($this->task->updateTask($data, $id)> 0){
            $this->response([
                'status' => true,
                'massage' => 'Task Has Been Updated'
            ], 200);
        }else{
            $this->response([
                'status' => false,
                'massage' => 'Update Task  Failed!',
            ], 400);
        }
    }
}